# Aplikasi Pencarian Rumah Sakit Sederhana

Aplikasi Pencarian Rumah Sakit Sederhana menggunakan Flutter dan Open Source API


## Demo
<p float="left">
<img src="https://github.com/adeputraprimasuhendri/rumahsakit/blob/main/screenshot/1.png" width="100"/>
<img src="https://github.com/adeputraprimasuhendri/rumahsakit/blob/main/screenshot/2.png" width="100"/>
<img src="https://github.com/adeputraprimasuhendri/rumahsakit/blob/main/screenshot/3.png" width="100"/>
</p>