package com.example.rumahsakit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
